# 接口协议 · 固定入口

成员把这份约定交给开发 AI，说明本次任务和预期效果即可。AI 负责读取 GitHub 上的当前协议、开发、测试和提交合并请求。

**AI 每次接任务先执行以下步骤，包括继续旧分支时。**

1. 使用成员已授权的 GitHub 身份访问主仓库 [FANTH0M6/FAN](https://github.com/FANTH0M6/FAN)，查询远程 `main` 当前的完整提交 SHA。使用 Git 时先核对远程地址并 fetch；使用连接器时从远端查询分支。
2. 在该 SHA 下读取 `team-site/AGENTS.md`。仅在初始搭建期间，已确认 main 中尚无此文件，且[初始 PR #1](https://github.com/FANTH0M6/FAN/pull/1) 仍开放、来源为同一仓库并指向 main 时，改用该 PR 的当前 head SHA。main 中出现协议后，每次均从 main 取。
3. 从选定的同一个 SHA 读取 `team-site/contracts/site.schema.json` 和项目源码。以该提交的协议为准处理本次任务。保留成员已有改动，再按远端协议建分支或续接任务。
4. 遇到访问失败，先区分登录、仓库权限和网络问题。可用包内示例离线预演；恢复访问后重新取远端协议并核对改动，再提交。
