import { fields } from "./validators.js";
import { check, snapshot } from "./contract.js";

export function createRuntime(initial = {}, registry = fields) {
  const instances = new Map();
  const state = new Map();
  const listeners = new Map();
  const dirty = new Set();
  let scheduled = false;

  function field(key) {
    if (!registry.has(key)) throw new TypeError("未声明的共享字段 " + String(key));
    return registry.get(key);
  }

  function set(key, value) {
    const rule = field(key);
    if (state.has(key) && Object.is(state.get(key), value)) return;
    const next = snapshot(value, key);
    check(rule.validate, next, key + "（" + rule.hint + "）");
    state.set(key, next);
    dirty.add(key);
    if (scheduled) return;
    scheduled = true;
    Promise.resolve().then(() => {
      scheduled = false;
      const keys = Array.from(dirty);
      dirty.clear();
      for (const name of keys) {
        for (const notify of Array.from(listeners.get(name) || [])) notify();
      }
    });
  }
  for (const [key, rule] of registry) {
    if (Object.prototype.hasOwnProperty.call(rule, "initial")) set(key, rule.initial);
  }
  for (const [key, value] of Object.entries(initial)) set(key, value);

  function attach(container, mount, { input = {}, onDone = () => {}, onError = console.error } = {}) {
    const previous = instances.get(container);
    if (previous) previous();

    let alive = true;
    let completed = false;
    const controller = new AbortController();
    const cleanups = [];
    const subscriptions = new Set();
    const slot = container.ownerDocument.createElement("section");
    container.replaceChildren(slot);

    function report(error) {
      const fallback = reportingError => console.error("模块异常与上报异常", error, reportingError);
      try {
        const result = onError(error);
        if (result && typeof result.then === "function") Promise.resolve(result).catch(fallback);
      } catch (reportingError) { fallback(reportingError); }
    }

    function release(fn) {
      try { fn(); } catch (error) { report(error); }
    }

    function onCleanup(fn) {
      if (typeof fn !== "function") throw new TypeError("清理操作必须是函数");
      if (alive) cleanups.push(fn);
      else release(fn);
    }

    function detach() {
      if (!alive) return;
      alive = false;
      instances.delete(container);
      for (const unsubscribe of subscriptions) unsubscribe();
      controller.abort();
      while (cleanups.length) release(cleanups.pop());
      if (container.firstElementChild === slot) container.replaceChildren();
    }

    function fail(error) {
      detach();
      report(error);
    }

    function watch(key, callback) {
      if (!alive) return () => {};
      field(key);
      let group = listeners.get(key);
      if (!group) listeners.set(key, group = new Set());
      let last = state.get(key);
      function notify() {
        const value = state.get(key);
        if (!alive || !group.has(notify) || Object.is(last, value)) return;
        last = value;
        try { callback(value); } catch (error) { fail(error); }
      }
      function unsubscribe() {
        group.delete(notify);
        if (!group.size && listeners.get(key) === group) listeners.delete(key);
        subscriptions.delete(unsubscribe);
      }
      group.add(notify);
      subscriptions.add(unsubscribe);
      try { callback(last); } catch (error) { unsubscribe(); throw error; }
      return unsubscribe;
    }

    const context = {
      get(key) { field(key); return state.get(key); },
      set: (key, value) => { if (alive) set(key, value); },
      signal: controller.signal,
      onCleanup,
      watch
    };
    function done(output) {
      if (!alive || completed) return;
      completed = true;
      Promise.resolve().then(() => {
        if (!alive) return;
        try { onDone(output); } catch (error) { fail(error); }
      });
    }

    instances.set(container, detach);
    try {
      const cleanup = mount(slot, input, done, context);
      if (typeof cleanup !== "function") throw new TypeError("mount 必须返回清理函数");
      onCleanup(cleanup);
    } catch (error) {
      fail(error);
    }
    return detach;
  }

  function stop() {
    for (const detach of Array.from(instances.values())) detach();
  }
  return { attach, stop };
}
