import { createRuntime } from "./runtime.js";
import { mount as controls } from "./modules/light-controls/index.js";
import { mount as preview } from "./modules/light-preview/index.js";

const runtime = createRuntime();
runtime.attach(document.querySelector("#controls"), controls);

const area = document.querySelector("#preview");
const toggle = document.querySelector("#toggle");
let removePreview = runtime.attach(area, preview);
toggle.addEventListener("click", () => {
  if (removePreview) {
    removePreview();
    removePreview = null;
  } else {
    removePreview = runtime.attach(area, preview);
  }
  toggle.setAttribute("aria-expanded", String(Boolean(removePreview)));
  toggle.textContent = removePreview ? "收起预览" : "展开预览";
});
