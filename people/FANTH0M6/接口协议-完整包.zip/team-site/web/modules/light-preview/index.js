export function mount(container, input, onDone, context) {
  container.innerHTML = '<div class="light-preview"><span class="light-disc"></span><span class="light-caption"></span></div>';
  const panel = container.querySelector(".light-preview");
  const caption = container.querySelector(".light-caption");
  return context.watch("light.level", value => {
    panel.style.setProperty("--level", value / 100);
    caption.textContent = "当前光照 " + value + "%";
  });
}
