export function mount(container, input, onDone) {
  container.innerHTML = `
    <h1>选一束光</h1>
    <p>你的选择会出现在下一页。</p>
    <div class="choices">
      <button type="button" class="tile sky-moon" data-choice="moon"><span class="orb" aria-hidden="true"></span><span class="tile-label">月亮</span></button>
      <button type="button" class="tile sky-sun" data-choice="sun"><span class="orb" aria-hidden="true"></span><span class="tile-label">太阳</span></button>
    </div>`;
  function select(event) {
    const button = event.target.closest("button[data-choice]");
    if (button) onDone({ choiceId: button.dataset.choice });
  }
  container.addEventListener("click", select);
  return () => container.removeEventListener("click", select);
}
