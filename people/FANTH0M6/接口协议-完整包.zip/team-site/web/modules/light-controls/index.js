export function mount(container, input, onDone, context) {
  container.innerHTML = `
    <label>光照强度<input type="range" min="0" max="100" step="1"></label>
    <output></output>`;
  const slider = container.querySelector("input");
  const output = container.querySelector("output");
  const change = () => context.set("light.level", slider.valueAsNumber);
  context.watch("light.level", value => {
    slider.value = String(value);
    output.textContent = value + "%";
  });
  slider.addEventListener("input", change, { signal: context.signal });
  return () => {};
}
