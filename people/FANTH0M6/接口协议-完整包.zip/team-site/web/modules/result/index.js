export function mount(container, input, onDone) {
  const moon = input.choiceId === "moon";
  container.innerHTML = `
    <div class="result-panel ${moon ? "sky-moon" : "sky-sun"}">
      <span class="orb" aria-hidden="true"></span>
      <h1>你选了${moon ? "月亮" : "太阳"}</h1>
    </div>
    <button class="replay" type="button">重新选择</button>`;
  const button = container.querySelector("button");
  const restart = () => onDone({ action: "restart" });
  button.addEventListener("click", restart);
  return () => button.removeEventListener("click", restart);
}
