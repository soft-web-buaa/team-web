import { mount as choice } from "./modules/choice/index.js";
import { mount as result } from "./modules/result/index.js";
import { empty, selection, restart } from "./validators.js";
import { check } from "./contract.js";

export const first = "choice";
export const scenes = {
  choice: {
    input: empty,
    mount: choice,
    next(output) {
      check(selection, output, "choice 输出");
      return { id: "result", input: { choiceId: output.choiceId } };
    }
  },
  result: {
    input: selection,
    mount: result,
    next(output) {
      check(restart, output, "result 输出");
      return { id: "choice", input: {} };
    }
  }
};
