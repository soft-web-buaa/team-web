import { scenes, first } from "./flow.js";
import { start } from "./host.js";

const container = document.querySelector("#scene");
function launch() {
  start(container, scenes, first, (error) => {
    console.error("模块运行失败", error);
    container.innerHTML = '<h1 role="alert">模块未能接入</h1><p>请检查当前模块的输入和输出。</p><button class="replay" type="button">重新开始</button>';
    const retry = container.querySelector("button");
    retry.addEventListener("click", launch, { once: true });
    retry.focus();
  });
}
launch();
