import { createRuntime } from "./runtime.js";
import { check } from "./contract.js";

// A flow occupies one slot. Other modules can remain mounted in the same runtime.
export function start(container, scenes, first, reportError, runtime = createRuntime()) {
  let detach = () => {};
  function enter(id, input) {
    const scene = scenes[id];
    if (!scene || typeof scene.mount !== "function") throw new Error("未知场景 " + id);
    if (scene.input) check(scene.input, input, id + " 输入");
    detach = runtime.attach(container, scene.mount, {
      input,
      onDone(output) {
        const next = scene.next(output);
        enter(next.id, next.input);
      },
      onError: reportError
    });
    if (container.firstElementChild && container.firstElementChild.tagName === "SECTION") container.focus();
  }
  try { enter(first, {}); } catch (error) { reportError(error); }
  return () => detach();
}
