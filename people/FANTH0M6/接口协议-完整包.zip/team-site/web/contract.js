export function check(validate, value, label) {
  if (!validate(value)) {
    const issue = validate.errors[0];
    throw new TypeError(label + (issue.instancePath || "") + " · " + issue.message);
  }
}

// Reject data that JSON.stringify would silently change or discard.
export function snapshot(value, path, parents = new Set()) {
  if (value === null || ["string", "boolean"].includes(typeof value) || Number.isFinite(value)) return value;
  if (typeof value !== "object" || parents.has(value)) throw new TypeError(path + " 需要无循环的 JSON 数据");
  const array = Array.isArray(value);
  if (!array && ![Object.prototype, null].includes(Object.getPrototypeOf(value))) throw new TypeError(path + " 需要普通 JSON 对象");
  parents.add(value);
  const copy = array
    ? Array.from(value, (item, i) => snapshot(item, path + "/" + i, parents))
    : Object.fromEntries(Object.entries(value).map(([k, v]) => [k, snapshot(v, path + "/" + k, parents)]));
  parents.delete(value);
  return Object.freeze(copy);
}
