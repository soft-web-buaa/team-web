import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import Ajv2020 from "ajv/dist/2020.js";
import standalone from "ajv/dist/standalone/index.js";
import { build } from "esbuild";

const root = new URL("../", import.meta.url);
const schema = JSON.parse(await readFile(new URL("contracts/site.schema.json", root), "utf8"));
const ajv = new Ajv2020({ strict: true, ownProperties: true, code: { source: true, esm: true, lines: true } });
ajv.addSchema(schema);
const exportsById = {};
const entries = [];
function pointer(key) {
  return encodeURIComponent(key.replaceAll("~", "~0").replaceAll("/", "~1"));
}
for (const [key, rule] of Object.entries(schema.properties)) {
  const name = "field" + entries.length;
  exportsById[name] = schema.$id + "#/properties/" + pointer(key);
  const validate = ajv.getSchema(exportsById[name]);
  if (Object.hasOwn(rule, "default") && !validate(rule.default)) throw Error("默认值不符合协议 " + key);
  const metadata = { hint: rule.description || key };
  if (Object.hasOwn(rule, "default")) metadata.initial = rule.default;
  entries.push(`[${JSON.stringify(key)}, { ...${JSON.stringify(metadata)}, validate: ${name} }]`);
}
for (const key of Object.keys(schema.$defs)) exportsById[key] = schema.$id + "#/$defs/" + pointer(key);
const source = standalone(ajv, exportsById) + "\nexport const fields = new Map([" + entries.join(",\n") + "]);";
const result = await build({
  stdin: { contents: source, resolveDir: fileURLToPath(root), sourcefile: "site.validators.js" },
  bundle: true, write: false, format: "esm", platform: "browser", target: "es2020",
  charset: "utf8", banner: { js: "// Generated from contracts/site.schema.json by npm run contracts." }
});
const file = new URL("web/validators.js", root);
const generated = result.outputFiles[0].text;
if (process.argv.includes("--check")) {
  const saved = await readFile(file, "utf8");
  if (saved.replaceAll("\r\n", "\n") !== generated.replaceAll("\r\n", "\n")) throw Error("请运行 npm run contracts 并提交 web/validators.js");
} else {
  await writeFile(file, generated);
}
