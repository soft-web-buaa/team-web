# 接口协议

配套运行器负责网页模块的装载、数据交接和退出清理。仓库附有顺序切换和同屏联动两个可运行样例。

**成员接入**：把[固定入口](接入约定.md)或完整包交给开发 AI，说清任务即可。AI 每次先从 GitHub 取当前协议和代码；团队以后更新协议时，组员继续使用原入口。

## 运行逻辑

[runtime.js](web/runtime.js) 管理模块的挂载、替换、卸载与共享数据。[host.js](web/host.js) 在同一套运行器上增加场景切换。模块拿到自己的 DOM 容器和通信接口，界面与业务逻辑都放在模块目录里。

```js
import { createRuntime } from "./runtime.js";
import { mount as controls } from "./modules/light-controls/index.js";
import { mount as preview } from "./modules/light-preview/index.js";

const app = createRuntime();
app.attach(document.querySelector("#controls"), controls);
const removePreview = app.attach(document.querySelector("#preview"), preview);
// 收起预览时调用 removePreview()，控制模块可以继续工作。
```

顺序体验看 [flow.js](web/flow.js)。多块同屏看 [live.js](web/live.js)。两种模式也能组合：把同一个 app 传给场景宿主的第五个参数，同时在另一个容器 attach 常驻模块。共享数据只保存在当前页面的运行器中。

## 启动

从仓库根目录执行以下命令。需要 Node.js 18 或更新版本，安装后即可运行，无需下载项目依赖。

```sh
cd team-site
npm start
```

浏览器打开 http://127.0.0.1:4173 。选“月亮”或“太阳”，从结果页点击“重新选择”。在同一目录运行 `npm test` 验证模块契约。程序使用浏览器原生 ES 模块，请通过 HTTP 访问。部署时把 web/ 的全部内容放入任意静态站点目录，包括网站子路径。

## 第一位队友怎样接入

在首页进入“同屏联动样例”。拖动滑杆，右侧预览同步更新；收起预览，再调整滑杆，重新展开时应直接显示最新光照。滑杆与预览分属两个目录，只共用协议里的 light.level 字段。

先把 [协作协议](AGENTS.md) 交给自己的 AI。打开 [结果模块](web/modules/result/index.js)，保留 mount 的参数、输出和清理函数，修改结果页呈现。刷新后各选一次日月，两种结果与重玩都正常，就完成了第一次模块替换。想增加第三个场景时，在 web/modules/ 新建同结构目录，再到 [流程表](web/flow.js) 登记切换条件。

| 想查什么 | 看哪里 |
| --- | --- |
| 两块模块如何传值 | [可运行的样例数据](fixtures/handoffs.json) |
| 公共颜色、字号与按钮 | [公共样式](web/theme.css) |
| 挂载、状态订阅、卸载和错误处理 | [运行器](web/runtime.js)、[场景宿主](web/host.js) |
| 数据交接、多实例和替换行为的自动检查 | [流程检查](checks/contracts.mjs)、[运行器检查](checks/runtime.mjs) |

## 版本协作

### 接口维护与自动验收

[接口源文件](contracts/site.schema.json) 同时描述共享状态和场景传值。编辑协议后在本目录运行 `npm ci`、`npm run contracts` 和 `npm test`。Ajv 根据 JSON Schema 2020-12 生成浏览器校验函数；本地预览只读取提交好的 JS。生成文件与源码是否一致可以用 `npm run check:contracts` 核对。[JSON Schema 校验词汇](https://json-schema.org/draft/2020-12/json-schema-validation) · [Ajv 独立校验函数](https://ajv.js.org/standalone.html)

模块用 AbortSignal 统一取消 DOM 监听，用 onCleanup 登记其他资源。错误处理参考 Vue 对用户回调的集中保护。实际接入示例见[亮度控制模块](web/modules/light-controls/index.js)。[DOM EventTarget 标准](https://dom.spec.whatwg.org/#interface-eventtarget) · [Vue 错误处理实现](https://github.com/vuejs/core/blob/v3.5.13/packages/runtime-core/src/errorHandling.ts)

PR 的 [接口协议检查](../.github/workflows/team-site.yml) 执行协议一致性检查、单元测试和浏览器联调。本地安装开发依赖后运行 `npm run test:browser` 可复测同一条路径，需要本机 Chrome。使用其他 Chromium 可执行文件时设置 BROWSER_PATH。脚本自行启动临时本地服务并在测试结束时关闭。[GitHub Actions 的 Node.js 测试流程](https://docs.github.com/en/actions/tutorials/build-and-test-code/nodejs)

AI 使用成员自己的账号提交 PR，附上验收动作和实际结果，由对接同学复测。答辩时可以用 PR 交接记录说明每个人的贡献。
