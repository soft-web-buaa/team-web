import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { start } from "../web/host.js";
import { scenes } from "../web/flow.js";

const samples = JSON.parse(await readFile(new URL("../fixtures/handoffs.json", import.meta.url), "utf8"));
for (const sample of samples) {
  test(sample.from + " → " + sample.to + " " + JSON.stringify(sample.output), () => {
    assert.deepEqual(scenes[sample.from].next(sample.output), { id: sample.to, input: sample.input });
  });
}

test("reject unknown choice and action", () => {
  assert.throws(() => scenes.choice.next({ choiceId: "unknown" }));
  assert.throws(() => scenes.result.next({}));
});

test("scene contracts reject missing, misspelled and unexpected payload fields", () => {
  assert.equal(scenes.choice.input({}), true);
  assert.equal(scenes.choice.input({ extra: true }), false);
  assert.equal(scenes.result.input({ choiceID: "sun" }), false);
  assert.equal(scenes.result.input({ choiceId: "moon", extra: 1 }), false);
  assert.throws(() => scenes.result.next({ action: "restart", extra: 1 }), /result/);
});

function fakeContainer() {
  return { ownerDocument: { createElement: () => ({}) }, replaceChildren() {}, focus() {} };
}

test("replace result, handle synchronous completion, ignore old clicks and clean once", async () => {
  const events = [];
  let previousDone;
  let restart;
  let mounts = 0;
  const modules = {
    choice: { ...scenes.choice, mount(slot, input, done) {
      mounts++;
      if (mounts === 1) {
        previousDone = done;
        done({ choiceId: "moon" });
        done({ choiceId: "sun" });
      }
      return () => events.push("leave choice");
    } },
    result: { ...scenes.result, mount(slot, input, done) {
      events.push(input.choiceId);
      restart = done;
      return () => events.push("leave result");
    } }
  };
  start(fakeContainer(), modules, "choice", assert.fail);
  await Promise.resolve();
  previousDone({ choiceId: "sun" });
  restart({ action: "restart" });
  await Promise.resolve();
  assert.equal(mounts, 2);
  assert.deepEqual(events, ["leave choice", "moon", "leave result"]);
});
