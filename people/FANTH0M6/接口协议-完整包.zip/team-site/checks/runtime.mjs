import { test } from "node:test";
import assert from "node:assert/strict";
import { createRuntime as projectRuntime } from "../web/runtime.js";
import { start } from "../web/host.js";

// Synthetic fields isolate the lifecycle tests from the site's evolving schema.
function createRuntime(initial) {
  const keys = ["x", "y", "step", "config"];
  return projectRuntime(initial, new Map(keys.map(key => [key, { validate: () => true, hint: key }])));
}

function area() {
  return {
    ownerDocument: { createElement: () => ({ tagName: "SECTION" }) },
    replaceChildren(child) { this.firstElementChild = child; },
    focus() {}
  };
}

function capture(runtime, slot = area()) {
  let api;
  const remove = runtime.attach(slot, (el, input, done, ctx) => {
    api = ctx;
    return () => {};
  });
  return { api, remove };
}

test("project contract rejects typos, invalid initial values and writes without notifying", async () => {
  for (const initial of [{ "light.levle": 1 }, { "light.level": -1 }]) {
    assert.throws(() => projectRuntime(initial), /light\./);
  }
  const { api } = capture(projectRuntime());
  const received = [];
  api.watch("light.level", v => received.push(v));
  assert.throws(() => api.get("light.levle"), /light.levle/);
  assert.throws(() => api.watch("light.levle", () => {}), /light.levle/);
  assert.throws(() => api.set("light.levle", 70), /light.levle/);
  for (const bad of ["80%", -1, 101, 4.5, undefined, NaN, Infinity]) {
    assert.throws(() => api.set("light.level", bad), /light.level/);
  }
  await Promise.resolve();
  assert.deepEqual(received, [50]);
  api.set("light.level", 0);
  await Promise.resolve();
  api.set("light.level", 100);
  await Promise.resolve();
  assert.deepEqual(received, [50, 0, 100]);
});

test("partial mount aborts listeners and unwinds every registered resource once", () => {
  const target = new EventTarget();
  const log = [];
  const runtime = projectRuntime();
  runtime.attach(area(), (el, input, done, ctx) => {
    target.addEventListener("tick", () => log.push("tick"), { signal: ctx.signal });
    ctx.onCleanup(() => log.push("first"));
    ctx.onCleanup(() => { log.push("second"); throw Error("cleanup failed"); });
    throw Error("mount failed");
  }, { onError: e => log.push(e.message) });
  target.dispatchEvent(new Event("tick"));
  runtime.stop();
  assert.deepEqual(log, ["second", "cleanup failed", "first", "mount failed"]);
});

test("failure in the error reporter preserves both errors and sibling deliveries", async t => {
  const log = [];
  t.mock.method(console, "error", (label, first, second) => log.push([first.message, second.message]));
  const runtime = projectRuntime();
  runtime.attach(area(), (el, input, done, ctx) =>
    ctx.watch("light.level", v => { if (v === 80) throw Error("render failed"); }),
  { onError() { throw Error("report failed"); } });
  const { api } = capture(runtime);
  const received = [];
  api.watch("light.level", v => received.push(v));
  api.set("light.level", 80);
  await Promise.resolve();
  assert.deepEqual(log, [["render failed", "report failed"]]);
  assert.deepEqual(received, [50, 80]);
});

test("one instance per slot; stale handles and late writes cannot affect a replacement", () => {
  const r = createRuntime({ x: 1 });
  const slot = area();
  const a = capture(r, slot);
  const b = capture(r, slot);
  a.remove();
  a.api.set("x", 2);
  assert.equal(b.api.get("x"), 1);
  assert.ok(slot.firstElementChild);
  r.stop();
  assert.equal(slot.firstElementChild, undefined);
});

test("six mounted modules receive only their keys and the last value in a burst", async () => {
  const r = createRuntime({ x: 0, y: 0 });
  const updates = [];
  const modules = Array.from({ length: 6 }, (_, i) => {
    const { api, remove } = capture(r);
    api.watch(i % 2 ? "y" : "x", value => updates.push([i, value]));
    return { api, remove };
  });
  updates.length = 0;
  modules[0].api.set("x", 1);
  modules[0].api.set("x", 2);
  modules[2].remove();
  await Promise.resolve();
  assert.deepEqual(updates, [[0, 2], [4, 2]]);
  const late = capture(r);
  let current;
  late.api.watch("x", v => { current = v; });
  assert.equal(current, 2);
  r.stop();
});

test("shared snapshots survive caller mutation and are isolated between applications", () => {
  const first = capture(createRuntime()).api;
  const second = capture(createRuntime()).api;
  const source = { levels: [1, 2] };
  first.set("config", source);
  source.levels.pop();
  assert.deepEqual(first.get("config"), { levels: [1, 2] });
  assert.throws(() => first.get("config").levels.pop(), TypeError);
  assert.equal(second.get("config"), undefined);
});

test("subscriber failure is isolated and does not skip another slot", async () => {
  const r = createRuntime();
  const log = [];
  const bad = area();
  r.attach(bad, (el, input, done, ctx) => {
    ctx.watch("x", v => { if (v === 1) throw Error("bad"); });
    return () => log.push("cleanup");
  }, { onError: e => log.push(e.message) });
  const good = capture(r);
  good.api.watch("x", v => { if (v) log.push(v); });
  good.api.set("x", 1);
  await Promise.resolve();
  good.api.set("x", 2);
  await Promise.resolve();
  assert.deepEqual(log, ["cleanup", "bad", 1, 2]);
  assert.equal(bad.firstElementChild, undefined);
});

test("scene changes keep sibling subscriptions and shared data alive; stop is idempotent", async () => {
  const r = createRuntime({ step: 0 });
  const seen = [];
  const sibling = capture(r);
  sibling.api.watch("step", v => seen.push(v));
  let done;
  let cleaned = 0;
  const slot = area();
  const leave = start(slot, {
    a: { mount(el, input, finish, ctx) {
      done = finish;
      ctx.set("step", 1);
      return () => cleaned++;
    }, next: () => ({ id: "b", input: {} }) },
    b: { mount(el, input, finish, ctx) {
      assert.equal(ctx.get("step"), 1);
      ctx.set("step", 2);
      return () => cleaned++;
    } }
  }, "a", assert.fail, r);
  done({});
  await Promise.resolve();
  await Promise.resolve();
  leave();
  leave();
  sibling.api.set("step", 3);
  await Promise.resolve();
  assert.deepEqual(seen, [0, 1, 2, 3]);
  assert.equal(cleaned, 2);
  r.stop();
  r.stop();
});

test("failed mount releases subscriptions; an unmounted pending completion is ignored", async () => {
  const r = createRuntime();
  const events = [];
  r.attach(area(), (el, input, done, ctx) => {
    ctx.watch("x", v => events.push(v));
    throw Error("failed mount");
  }, { onError: e => events.push(e.message) });
  const remove = r.attach(area(), (el, input, done, ctx) => {
    done({});
    ctx.set("x", 7);
    return () => events.push("removed");
  }, { onDone: () => events.push("late") });
  remove();
  await Promise.resolve();
  assert.deepEqual(events, [undefined, "failed mount", "removed"]);
});
