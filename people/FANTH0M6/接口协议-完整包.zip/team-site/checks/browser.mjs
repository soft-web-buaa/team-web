import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { test } from "node:test";
import { chromium } from "playwright-core";

test("browser: sequential flow, live updates and remount", { timeout: 60000 }, async t => {
  const server = spawn(process.execPath, ["tools/serve.js"], {
    env: { ...process.env, PORT: "0" }, stdio: ["ignore", "pipe", "inherit"]
  });
  t.after(() => server.kill());
  const lines = createInterface({ input: server.stdout });
  const first = await lines[Symbol.asyncIterator]().next();
  assert.match(first.value || "", /^Local: http:\/\/127\.0\.0\.1:\d+$/);
  const url = first.value.slice("Local: ".length);
  const browser = await chromium.launch(process.env.BROWSER_PATH
    ? { executablePath: process.env.BROWSER_PATH } : { channel: "chrome" });
  t.after(() => browser.close());
  const page = await browser.newPage();
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", event => { if (event.type() === "error") errors.push(event.text()); });
  for (const width of [360, 1280]) {
    await page.setViewportSize({ width, height: 800 });
    await page.goto(url);
    for (const name of ["月亮", "太阳"]) {
      await page.getByRole("button", { name }).click();
      await page.getByRole("heading", { name: "你选了" + name }).waitFor();
      await page.getByRole("button", { name: "重新选择" }).click();
    }
    await page.getByRole("link", { name: "同屏联动样例" }).click();
    const slider = page.getByRole("slider", { name: "光照强度" });
    await slider.press("End");
    await page.getByText("当前光照 100%").waitFor();
    await page.getByRole("button", { name: "收起预览" }).click();
    assert.equal(await page.locator(".light-preview").count(), 0);
    await slider.press("Home");
    await page.getByRole("button", { name: "展开预览" }).click();
    await page.getByText("当前光照 0%").waitFor();
  }
  assert.deepEqual(errors, []);
});
